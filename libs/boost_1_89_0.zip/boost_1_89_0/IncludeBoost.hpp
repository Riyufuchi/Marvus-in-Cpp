//==============================================================================
// File       : IncludeBoost.hpp
// Author     : riyufuchi
// Created on : Dec 8, 2025
// Last edit  : Dec 8, 2025
// Copyright  : Copyright (c) 2025, riyufuchi
// Description: Marvus-in-Cpp
//==============================================================================

#ifndef INCLUDE_BOOST_HPP_
#define INCLUDE_BOOST_HPP_

// ----------------------------
// General Boost configuration
// ----------------------------

// Make Boost.System header-only (avoid linking Boost.System library)
#define BOOST_ERROR_CODE_HEADER_ONLY

// ----------------------------
// Core headers used by multiple modules
// ----------------------------
#include "boost/config.hpp"
#include "boost/type_traits.hpp"

// ----------------------------
// Boost.Asio (networking)
// ----------------------------
#include "boost/asio.hpp"

#include "boost/endian.hpp"

// ----------------------------
// Boost.Multiprecision (high-precision decimals)
// ----------------------------
#include "boost/multiprecision/cpp_dec_float.hpp"
#include "boost/multiprecision/cpp_int.hpp" // optional for big integers

#endif
