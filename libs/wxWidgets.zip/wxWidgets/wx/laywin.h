/////////////////////////////////////////////////////////////////////////////
// Name:        wx/laywin.h
// Purpose:     wxSashLayoutWindow base header
// Author:      Julian Smart
// Created:
// Copyright:   (c) Julian Smart
// Licence:     wxWindows licence
/////////////////////////////////////////////////////////////////////////////

#ifndef _WX_LAYWIN_H_BASE_
#define _WX_LAYWIN_H_BASE_

#include "wx/generic/laywin.h"

#endif
    // _WX_LAYWIN_H_BASE_
